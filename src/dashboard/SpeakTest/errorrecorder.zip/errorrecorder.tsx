'use client';

import React, { useState, useRef } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Mic, Loader2 } from 'lucide-react';

// 👇 Add this to avoid red underline
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }

   interface SpeechRecognitionEvent extends Event {
    results: SpeechRecognitionResultList;
  }

  interface SpeechRecognitionErrorEvent extends Event {
    error: string;
  }
}

type SpeechRecognition = any;

const VoiceTranscriber = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transcribedText, setTranscribedText] = useState('');
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const handleStartRecording = () => {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported in this browser.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsRecording(true);
      setIsProcessing(true);
      setTranscribedText('');
    };

    recognition.onresult = (event: SpeechRecognitionEvent) => {
  const speechResult = event.results[0][0].transcript;
  setTranscribedText(speechResult);
};

  recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
  console.error('Speech recognition error:', event.error);
  setTranscribedText('Error: ' + event.error);
};

    recognition.onend = () => {
      setIsRecording(false);
      setIsProcessing(false);
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const handleStopRecording = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
  };

  return (
    <div className="flex flex-row w-full mx-auto gap-3">
      {/* Left: Recorder Button */}
      <div className="bg-[#2E2D2D] h-[16vh] w-20/5 flex items-center justify-center rounded-md">
        <Button className='bg-[#64acff]  rounded-full'
          variant={isRecording ? 'destructive' : 'default'}
          onClick={isRecording ? handleStopRecording : handleStartRecording}
        >
          <Mic className=" h-4 w-4 text-white " />

        </Button>
        <span className="ml-2 text-white">
          {isRecording ? 'Recording...' : 'Start Recording'}
        </span>
      </div>
<p style={{borderRadius:"50px", height:"8vh", width:"25vw",border:"1px solid grey", textAlign:"center", paddingTop:"5px", marginTop:"15px" }}>or</p>
      {/* Right: Text Area or Loader */}
      <div className="bg-[#2E2D2D] h-[16vh] w-20/5 flex items-center justify-center rounded-md" style={{marginLeft:"0px"}}>
        {isRecording && isProcessing ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="animate-spin h-5 w-5" />
            Your recording is processing...
          </div>
        ) : (
          <Textarea
            className="w-full h-[16vh] "
            rows={6}
            placeholder="Enter your prompt here..."
            value={transcribedText}
            onChange={(e) => setTranscribedText(e.target.value)}
          />
        )}
      </div>
    </div>
  );
};

export default VoiceTranscriber;
